import streamlit as st

# 页面配置只能设置一次，在主入口文件中
st.set_page_config(page_title="📚 IELTS Writing Tool", layout="wide")

import app_bar
import app_pie
import app_bar_easy
import app_pie_easy

# 页面选择
page = st.sidebar.selectbox("Please choose a question", ["Bar", "Bar_easy", "Pie", "Pie_easy"])

if page == "Bar":
    app_bar.show()
if page == "Bar_easy":
    app_bar_easy.show()
if page == "Pie_easy":
    app_pie_easy.show()
elif page == "Pie":
    app_pie.show()
